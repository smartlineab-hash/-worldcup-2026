# 🚀 دليل رفع التطبيق — خطوة بخطوة

## المطلوب قبل البداية
- حساب GitHub (مجاني): github.com
- حساب Vercel (مجاني): vercel.com
- Node.js مثبت على جهازك: nodejs.org

---

## الخطوة 1 — تجهيز الأيقونات

التطبيق محتاج صورتين:
- `icon-192.png` (192×192 بكسل)
- `icon-512.png` (512×512 بكسل)

اعمل أيقونة كرة قدم أو شعار كأس العالم وحطها في مجلد `public/`

يمكن تصمم مجاناً على: canva.com أو icon.kitchen

---

## الخطوة 2 — رفع على GitHub

افتح Terminal (أو Command Prompt) وشغّل:

```bash
# 1. ادخل على مجلد المشروع
cd worldcup-pwa

# 2. ابدأ git
git init
git add .
git commit -m "first commit"

# 3. اربطه بـ GitHub (بعد ما تعمل repo جديد على github.com)
git remote add origin https://github.com/اسمك/worldcup-2026.git
git push -u origin main
```

---

## الخطوة 3 — النشر على Vercel (مجاني)

1. روح على **vercel.com** وسجل دخول
2. اضغط **"Add New Project"**
3. اختار الـ repository من GitHub
4. اضغط **"Deploy"** — خلاص! 🎉

رح يعطيك رابط مثل:
`https://worldcup-2026.vercel.app`

---

## الخطوة 4 — تثبيت التطبيق على الموبايل

### على iPhone (Safari):
1. افتح الرابط بـ Safari
2. اضغط زر المشاركة ↑
3. اختار **"أضف إلى الشاشة الرئيسية"**
4. اضغط **"إضافة"**
✅ التطبيق رح يظهر على الشاشة زي أي app!

### على Android (Chrome):
1. افتح الرابط بـ Chrome
2. رح يظهر بانر تلقائي "تثبيت التطبيق"
3. أو اضغط ⋮ ثم **"إضافة إلى الشاشة الرئيسية"**

---

## الخطوة 5 — شارك الرابط!

شارك الرابط على واتساب وانستغرام — أي شخص يفتحه على موبايله يقدر يثبته!

---

## 💰 التكلفة الكاملة: $0

| الخدمة | التكلفة |
|--------|---------|
| GitHub | مجاني |
| Vercel | مجاني |
| Domain افتراضي (.vercel.app) | مجاني |
| **المجموع** | **$0** |

> اختياري: لو بدك domain خاص مثل `worldcup26.com` — بتكلف ~$10/سنة من Namecheap أو GoDaddy

---

## ⚡ أوامر مفيدة

```bash
# شغّل محلياً على جهازك للتجربة
npm install
npm start
# افتح: http://localhost:3000

# بناء النسخة النهائية
npm run build
```

---

## 🆘 مشاكل شائعة

**"npm not found"** → ثبّت Node.js من nodejs.org

**"permission denied"** → أضف sudo قبل الأمر (Mac/Linux)

**الأيقونة مش ظاهرة** → تأكد الصور موجودة في مجلد public/

---

مبروك! 🏆 تطبيقك شغّال على كل الموبايلات بدون App Store وبدون مصاريف!
